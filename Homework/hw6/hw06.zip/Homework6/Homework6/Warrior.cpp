#include "Warrior.h"
#include "Noble.h"
#include <string>
#include <iostream>

using namespace std;
namespace WarriorCraft
{
			Warrior::Warrior(const string& name, int str) :name(name), str(str), employer(nullptr)
			{	}

			string Warrior::getName() const
			{
				return name;
			}

			int Warrior::getStr() const
			{
				return str;
			}

			void Warrior::setStr(double val)
			{
				str = val;
			}

			void Warrior::display() const
			{
				cout << name << ": " << str << endl;
			}

			void Warrior::setEmployer(Noble*& n)
			{
				employer = n;
			}

			void Warrior::runaway()
			{
				employer->removeWarrior(name);
				cout << name << " flees in terror, abandoning his lord, " << employer->getName() <<endl;
				employer = nullptr;
			}

}