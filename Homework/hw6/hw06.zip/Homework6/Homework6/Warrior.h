#ifndef WARRIOR_H
#define WARRIOR_H

#include <string>
#include <iostream>

namespace WarriorCraft
{
	class Noble;
	class Warrior
	{
	public:
		Warrior(const std::string& name, int str);

		std::string getName() const;

		int getStr() const;

		void setStr(double val);

		void display() const;

		void runaway();

		void setEmployer(Noble*& n);
	private:
		std::string name;
		int str;
		Noble* employer;
	};
}

#endif