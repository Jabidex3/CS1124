#ifndef NOBLE_H
#define NOBLE_H

#include <string>
#include <vector>
#include <iostream>

namespace WarriorCraft
{
	class Warrior;

	class Noble
	{	
	public:
		Noble(const std::string &name);

		std::string getName() const;

		std::vector<Warrior*> getWarriors();

		bool aliveNow();

		void hire(Warrior& combatant);

		void fire(Warrior& combatant);

		void setAlive(bool thing);

		void battle(Noble& otherNoble);
		
		void removeWarrior(std::string runaway);
	private:
		std::string name;
		std::vector <Warrior*> warriors;
		bool isAlive = true;
	};
	std::ostream& operator<<(std::ostream& os, Noble& noble);
}
#endif