/*
Jabid Methun
CS-UY 1124 Section B
jhm414
N14285139
HW #7
*/
#include "Polynomial.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;
using namespace Math;

int main()
{
	vector<int> co = { 5, 9, 7, 8, 2, 6, 3 };
	Polynomial p1(6, co);
	Polynomial p2 = p1;
	cout << "p1 = " << p1 << endl;
	cout << "p2 = " << p2 << endl;
	Polynomial p3(3, { 7, 1, 0, 4});
	cout << "p3 = " << p3 << endl;
	vector<int> co2 = { 8, 1, 6, 1, 7, 4 };
	Polynomial p4(5, co2);
	vector<int> co3 = { 5, 2, 7, 1, 3};
	Polynomial p5(4, co3);
	cout << "p4 = " << p4 << endl;
	cout << "p5 = " << p5 << endl;
	cout << endl;
	
	//== test
	cout << (p1 == p2) << endl;
	cout << (p1 == p4) << endl;
	cout << (p1 == p5) << endl;
	cout << endl;
	
	//!= test
	cout << (p1 != p2) << endl;
	cout << (p1 != p4) << endl;
	cout << (p1 != p5) << endl;
	cout << endl;

	//+= test
	p1 += p2;
	cout << "p1 += p2 is " << p1 << endl;

	p2 += p4;
	cout << "p2 += p4 is " << p2 << endl;
	cout << endl;

	//+ test
	cout << "p4 + p3 is " << p4 + p3 << endl;
	cout << "p5 + p3 is " << p5 + p3 << endl;
	cout << endl;

	//evaluate
	cout << p3.evaluate(3) << endl;
	cout << p5.evaluate(2) << endl;
	cout << endl;
	system("pause");
}
