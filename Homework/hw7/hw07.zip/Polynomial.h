/*
Jabid Methun
CS-UY 1124 Section B
jhm414
N14285139
HW #7
*/
#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include <iostream>
#include <string>
#include <vector>

namespace Math
{
	struct Node
	{
		int data;
		Node* next;
		Node(int data = 0, Node* next = nullptr);
		void add(int dat);
	};

	void listClear(Node*& headPtr);
	Node* listDuplicate(Node* headPtr);

	class Polynomial
	{
		friend std::ostream& operator<<(std::ostream& os, const Polynomial& p);
	private:
		Node* headptr;
		int degree;
	public:
		Polynomial(int degree, std::vector<int>coefficients);
		~Polynomial();
		Polynomial(const Polynomial& p);
		Polynomial& operator=(const Polynomial& p);
		Polynomial& operator+=(Polynomial& other);
		Polynomial operator+(Polynomial& other);
		bool operator==(Polynomial& other);
		bool operator!=(Polynomial& other);
		int evaluate(int x);
	};
}

#endif