/*
Jabid Methun
CS-UY 1124 Section B
jhm414
N14285139
HW #7
*/
#include "Polynomial.h"
#include <iostream>

using namespace std;
namespace Math
{
		Node::Node(int data, Node* next) : data(data), next(next) 
		{}

		void Node::add(int data)
		{
			Node* temp = this;
			while (temp->next != nullptr)
			{
				temp = temp->next;
			}
			temp->next = new Node(data);
		}

		void listClear(Node*& headPtr)
		{
			if (headPtr == nullptr) return;
			Node* trail = headPtr;
			Node* lead = headPtr->next;

			while (lead != nullptr) {
				delete trail;
				trail = lead;
				lead = lead->next;
			}
			delete trail;
			headPtr = nullptr;
		}

		Node* listDuplicate(Node* headPtr) 
		{
			if (headPtr == nullptr) return nullptr;
			Node* result = new Node(headPtr->data);
			Node* last = result;
			Node* p = headPtr->next;

			while (p != nullptr)
			{
				last->next = new Node(p->data);
				last = last->next;
				p = p->next;
			}
			return result;
		}

		Polynomial::Polynomial(int degree, vector<int>coefficients) : degree(degree), headptr(new Node(coefficients[0]))
		{
			for (size_t i = 0; i < coefficients.size(); i++)
			{
				headptr->add(coefficients[i]);
			}
		}

		Polynomial::~Polynomial()
		{
			degree = 0;
			listClear(headptr);
		}

		Polynomial::Polynomial(const Polynomial& p)
		{
			degree = p.degree;
			headptr = listDuplicate(p.headptr);
		}

		Polynomial& Polynomial::operator=(const Polynomial& p)
		{
			if (this != &p)
			{
				degree = 0;
				listClear(headptr);
				degree = p.degree;
				headptr = listDuplicate(p.headptr);
			}
			return *this;
		}

		int Polynomial::evaluate(int x)
		{
			int result = 0;
			int ctr = 0;
			Node* temp = headptr;
			
			while (temp->next != nullptr)
			{
				int exp = 1;
				for (int i = 0; i < ctr; i++)
				{
					exp *= x;
				}
				ctr++;
				temp = temp->next;
				result += temp->data*exp;
				
			}
			return result;
		}

		Polynomial& Polynomial::operator+=(Polynomial& other)
		{
			Node* temphead = headptr;
			Node* tempOther = other.headptr;
			while (temphead != nullptr)
			{
				if (tempOther != nullptr)
				{
					temphead->data += tempOther->data;
					tempOther = tempOther->next;
					temphead = temphead->next;
				}
				else
					temphead = temphead->next;
			}
			return *this;
		}
		
		Polynomial Polynomial::operator+(Polynomial& other)
		{
			Polynomial temp = *this;
			return temp += other;	
		}
		
		bool Polynomial::operator==(Polynomial& other)
		{
			if (degree != other.degree)
				return false;
			else
			{
				while (other.headptr != nullptr)
				{
					if (headptr->data != other.headptr->data)
					{
						return false;
					}
					break;
				}
				return true;
			}
		}

		bool Polynomial::operator!=(Polynomial& other) 
		{ 
			return !(*this == other); 
		}
		
	
		ostream& operator<<(ostream& os, const Polynomial& p)
		{
			int deg = p.degree;
			Node* poly = p.headptr;
			vector<int> display;
			while (poly != nullptr)
			{
				display.push_back(poly->data);
				poly = poly->next;
			}
			for (int i = display.size() - 1; i >= 0 ; i--)
			{
				if (display[i] != 0)
				{
					if (display[i] != 1)
					{
						if (deg == p.degree)
						{
							if (deg == 1)
								os << display[i] << "x";
							else
								os << display[i] << "x^" << deg;
						}
						else if (deg > 1)
							os << " + " << display[i] << "x^" << deg;
						else if (deg == 1)
						{
							os << " + " << display[i] << "x";
						}
						else if (deg == 0)
						{
							os << " + " << display[i] << " ";
						}
					}
					else
					{
						if (deg == p.degree)
						{
							if (deg == 1)
								os << "x";
							else if (deg > 1)
								os << "x^" << deg;
						}
						else if (deg > 1)
							os << " + " << "x^" << deg;
						else if (deg == 1)
						{
							os << " + " << "x";
						}
					}
				}
				deg--;
			}
			return os;
		}
}