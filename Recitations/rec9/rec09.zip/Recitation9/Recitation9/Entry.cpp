#include "Entry.h"
#include <iostream>
using namespace std;

namespace worker
{
	Entry::Entry(const string& aName, unsigned aRoom, unsigned aPhone,
		Position& aPosition)
		: name(aName), room(aRoom), phone(aPhone), pos(&aPosition) {
	}
	ostream& operator<<(ostream& os, const Entry& e) {
		os << e.name << ' ' << e.room << ' ' << e.phone;
		return os;
	} // operato<<
	string Entry::getName()const{
		return name;
	}
	unsigned Entry::getNum()const{
		return phone;
	}
}