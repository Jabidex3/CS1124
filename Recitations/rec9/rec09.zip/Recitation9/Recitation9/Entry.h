#ifndef ENTRY_H
#define ENTRY_H

#include <string>
#include <iostream>
#include "Position.h"

namespace worker
{
	class Entry
	{
	private:
		std::string name;
		unsigned room;
		unsigned phone;
		Position *pos;

	public:
		Entry(const std::string& aName, unsigned aRoom, unsigned ph, Position& aPhone);
		friend std::ostream& operator<<(std::ostream& os, const Entry& e);
		std::string getName() const;
		unsigned getNum() const;
	};
}

#endif