#include "Directory.h"
#include <iostream>
using namespace std;

namespace worker
{
	Directory::Directory()
		: capacity(2), size(0), entries(new Entry*[2])
	{
		// Should we do this?  What do you think?
		for (size_t i = 0; i < capacity; i++) {
			entries[i] = nullptr;
		} // for
	} // Directory()

	Directory::~Directory()
	{
		cout << "destructor" << endl;
		for (size_t i = 0; i < size; i++)
		{
			entries[i] = nullptr;
			delete entries[i];
		}
		delete[]entries;
	}

	Directory::Directory(const Directory& dir)
	{
		cout << "copy constructor" << endl;
		size = dir.size;
		capacity = dir.capacity;
		entries = new Entry*[capacity];

		for (size_t i = 0; i < dir.size; i++)
		{
			entries[i] = new Entry(*(dir.entries[i]));
		}
	}

	Directory& Directory::operator=(const Directory& dir)
	{
		cout << "assignment operator" << endl;
		if (this != &dir)
		{
			for (size_t i = 0; i < size; i++)
			{
				entries[i] = nullptr;
				delete entries[i];
			}
			delete[]entries;

			size = dir.size;
			capacity = dir.capacity;
			for (size_t i = 0; i < dir.size; i++)
			{
				entries[i] = new Entry(*(dir.entries[i]));
			}
		}
		return *this;
	}

	ostream& operator<<(ostream& os, const Directory& dir)
	{
		for (size_t i = 0; i < dir.size; i++)
			os << *dir.entries[i] << endl;
		return os;
	}

	unsigned Directory::operator[](const string& name)
	{
		for (size_t i = 0; i < size; i++)
		{
			if (name == entries[i]->getName())
				return entries[i]->getNum();
		}
	}


	void Directory::add(const string& name, unsigned room, unsigned ph, Position& pos) {
		if (size == capacity)	{
			Entry** temp = new Entry*[capacity *= 2];
			for (size_t i = 0; i < size; i++)
			{
				temp[i] = entries[i];
			}
			delete[] entries;
			entries = temp;
		} // if
		entries[size] = new Entry(name, room, ph, pos);
		++size;
	} // add
}