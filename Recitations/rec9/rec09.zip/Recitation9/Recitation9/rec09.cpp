/*
	Jabid Methun
	CS-UY 1124
	Section: B
	jhm414
	N14285139
	Rec09
*/

/*
Recitation 09
CS1124

Focus: Copy Control.  Uses dynamic array of pointers.
*/
#include "Directory.h"
#include <string>
#include <iostream>
using namespace std;
using namespace worker;
/*
class Position
{
public:
	Position(const string& aTitle, double aSalary)
		: title(aTitle), salary(aSalary) {}
	string getTitle() const { return title; }
	double getSalary() const { return salary; }
	void changeSalaryTo(double d) { salary = d; }
private:
	string title;
	double salary;
}; // class Position

class Entry
{
public:
	Entry(const string& aName, unsigned aRoom, unsigned aPhone,
		Position& aPosition)
		: name(aName), room(aRoom), phone(aPhone), pos(&aPosition) {
	}
	friend ostream& operator<<(ostream& os, const Entry& e) {
		os << e.name << ' ' << e.room << ' ' << e.phone;
		return os;
	} // operato<<
	string getName()const{
		return name;
	}
	unsigned getNum()const{
		return phone;
	}
private:
	string name;
	unsigned room;
	unsigned phone;
	Position* pos;
}; // class Entry

class Directory
{
public:
	Directory()
		: capacity(2), size(0), entries(new Entry*[2])
	{
		// Should we do this?  What do you think?
		for (size_t i = 0; i < capacity; i++) {
			entries[i] = nullptr;
		} // for
	} // Directory()

	~Directory()
	{
		cout << "destructor" << endl;
		for (size_t i = 0; i < size; i++)
		{
			entries[i] = nullptr;
			delete entries[i];
		}
		delete[]entries;
	}

	Directory(const Directory& dir)
	{
		cout << "copy constructor" << endl;
		size = dir.size;
		capacity = dir.capacity;
		entries = new Entry*[capacity];

		for (size_t i = 0; i < dir.size; i++)
		{
			entries[i] = new Entry(*(dir.entries[i]));
		}
	}

	Directory& operator=(const Directory& dir)
	{
		cout << "assignment operator" << endl;
		if (this != &dir)
		{
			for (size_t i = 0; i < size; i++)
			{
				entries[i] = nullptr;
				delete entries[i];
			}
			delete[]entries;

			size = dir.size;
			capacity = dir.capacity;
			for (size_t i = 0; i < dir.size; i++)
			{
				entries[i] = new Entry(*(dir.entries[i]));
			}
		}
		return *this;
	}

	friend ostream& operator<<(ostream& os, const Directory& dir);


	unsigned operator[](const string& name) const
	{
		for (size_t i = 0; i < size; i++)
		{
			if (name == entries[i]->getName())
				return entries[i]->getNum();
		}
	}


	void add(const string& name, unsigned room, unsigned ph, Position& pos) {
		if (size == capacity)	{
			Entry** temp = new Entry*[capacity *= 2];
			for (size_t i = 0; i < size; i++)
			{
				temp[i] = entries[i];
			}
			delete[] entries;
			entries = temp;
		} // if
		entries[size] = new Entry(name, room, ph, pos);
		++size;
	} // add
private:
	Entry** entries;
	size_t size;
	size_t capacity;
}; // class Directory*/

void doNothing(Directory dir) { cout << dir << endl; }
/*ostream& operator<<(ostream& os, const Directory& dir)
{
	for (size_t i = 0; i < dir.size; i++)
		os << *dir.entries[i] << endl;
	return os;
}*/
int main()
{

	// Model as if there are these four kinds 
	// of position in the problem:
	Position boss("Boss", 3141.59);
	Position pointyHair("Pointy Hair", 271.83);
	Position techie("Techie", 14142.13);
	Position peon("Peonissimo", 34.79);

	// Create a Directory
	Directory d;
	d.add("Marilyn", 123, 4567, boss);
	cout << d << endl;

	Directory d2 = d;	// What function is being used??
	d2.add("Gallagher", 111, 2222, techie);
	d2.add("Carmack", 314, 1592, techie);
	cout << d2 << endl;

	cout << "Calling doNothing\n";
	doNothing(d2);
	cout << "Back from doNothing\n";

	Directory d3;
	d3 = d2;
	system("pause");
} // main