#ifndef DIRECTORY_H
#define DIRECTORY_H

#include "Position.h"
#include "Entry.h"

namespace worker
{
	class Directory
	{
	private:
		Entry **entries;
		size_t size;
		size_t capacity;

	public:
		Directory();
		Directory(const Directory& dir);
		~Directory();
		void add(const std::string &name, unsigned room, unsigned ph, Position& pos);
		friend std::ostream& operator<<(std::ostream& os, const Directory& dir);
		Directory &operator=(const Directory& dir);
		unsigned operator[](const std::string& name);
	};
}

#endif