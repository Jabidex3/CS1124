#ifndef POSITION_H
#define POSITION_H

#include <string>

namespace worker
{
	class Position
	{
	private:
		std::string title;
		double salary;

	public:
		Position(const std::string& aTitle, double aSalary);
		std::string getTitle() const;
		double getSalary() const;
		void changeSalaryTo(double d);
	};
}

#endif