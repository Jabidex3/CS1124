#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>

namespace CS1124
{
	class Rational{
	public:
		
		Rational();
		Rational(int n);
		Rational(int n, int d);
		int greatestCommonDivisor(int x, int y);
		int getNumerator();
		int getDenominator();
		void setNumerator(int num);
		void setDenominator(int denom);
		void normalize();
		Rational& operator+=(const Rational& rhs);
		Rational& operator++();
		Rational operator++(int x);
		Rational& operator--();
		Rational operator--(int x);
	private:
		int numerator;
		int denominator;
	};

	Rational operator+(Rational& a,  Rational& b);
	bool operator==(const Rational& a, const Rational& b);
	bool operator==(const Rational& a, int x);
	bool operator!=(const Rational& a, const Rational& b);
	std::istream& operator>>(std::istream& is, Rational& rat);
	std::ostream& operator<<(std::ostream& os, Rational& rat);
}

#endif