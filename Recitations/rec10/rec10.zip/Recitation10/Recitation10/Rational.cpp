#include "Rational.h"
#include<iostream>

using namespace std;
namespace CS1124
{
	Rational::Rational() :numerator(0), denominator(1){}
	Rational::Rational(int n) : numerator(n), denominator(1){}
	Rational::Rational(int n, int d) : numerator(n), denominator(d){}
	
	int Rational::greatestCommonDivisor(int x, int y) {
		while (y != 0) {
			int temp = x % y;
			x = y;
			y = temp;
		}
		return x;
	}

	int Rational::getNumerator()
	{
		return numerator;
	}

	int Rational::getDenominator()
	{
		return denominator;
	}

	void Rational::setNumerator(int num)
	{
		numerator=num;
	}

	void Rational::setDenominator(int denom)
	{
		denominator = denom;
	}

	void  Rational::normalize()
	{
		int gcd = greatestCommonDivisor(numerator, denominator);
		numerator = numerator / gcd;
		denominator = denominator / gcd;
	}

	istream& operator>>(istream& is, Rational& rat)
	{
		int n, d;
		char ch;
		is >> n >> ch >> d;
		rat.setNumerator(n);
		rat.setDenominator(d);
		return is;
	}

	ostream& operator<<(ostream& os, Rational& rat)
	{
		rat.normalize();
		cout << rat.getNumerator() << '/' << rat.getDenominator();
		return os;
	}

	Rational& Rational::operator+=(const Rational& rhs)
	{
		if (denominator != rhs.denominator)
		{
			numerator = (numerator*rhs.denominator) + (rhs.numerator * denominator);
			denominator *= rhs.denominator;
		}
		else
		{
			numerator = numerator + rhs.numerator;
		}
		return *this;
	}

	Rational operator+(Rational& a, Rational& b)
	{
		Rational result(a);
		return result += b;
	}

	bool operator==(const Rational& a, const Rational& b)
	{
		Rational aCopy(a);
		Rational bCopy(b);
		aCopy.normalize();
		bCopy.normalize();
		if (aCopy.getNumerator() == bCopy.getNumerator() && aCopy.getDenominator() == bCopy.getDenominator())
		{
			return true;
		}
		else
			return false;
	}
	bool operator==(const Rational& a, int x)
	{
		Rational xCop(x);
		Rational aCopy(a);
		aCopy.normalize();
		
		if (aCopy.getNumerator() == xCop.getNumerator() && aCopy.getDenominator() == xCop.getDenominator())
		{
			return true;
		}
		else
			return false;
	}

	bool operator!=(const Rational& a, const Rational& b)
	{
		Rational aCopy(a);
		Rational bCopy(b);
		aCopy.normalize();
		bCopy.normalize();
		if (aCopy.getNumerator() == bCopy.getNumerator() && aCopy.getDenominator() == bCopy.getDenominator())
		{
			return false;
		}
		else
			return true;
	}

	Rational& Rational::operator++()
	{
		numerator += denominator;
		return *this;
	}

	Rational Rational::operator++(int i)
	{
		Rational origValue(*this);
		numerator += denominator;
		return origValue;
	}

	Rational& Rational::operator--()
	{
		numerator -= denominator;
		return *this;
	}

	Rational Rational::operator--(int i)
	{
		Rational origValue(*this);
		numerator -= denominator;
		return origValue;
	}
}