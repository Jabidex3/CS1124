#include "Registrar.h"
#include "Student.h"
#include "Course.h"
#include<iostream>

using namespace std;
namespace BrooklynPoly
{
	ostream& operator<<(ostream& os, const Registrar& r);
	void Registrar::addCourse(const string& name)
	{
		courses.push_back(new Course(name));
	}

	void Registrar::addStudent(const string& name)
	{
		students.push_back(new Student(name));
	}

	Course* Registrar::findCourse(const string& name)
	{
		for (size_t i = 0; i < courses.size(); i++)
		{
			if (courses[i]->getName() == name)
				return courses[i];
		}
		return nullptr;
	}

	Student* Registrar::findStudent(const string& name)
	{
		for (size_t i = 0; i < students.size(); i++)
		{
			if (students[i]->getName() == name)
				return students[i];
		}
		return nullptr;
	}
	void Registrar::cancelCourse(const std::string& name)
	{
		
		for (size_t i = 0; i < courses.size(); i++)
		{
			if (name == courses[i]->getName())
			{
				courses.erase(courses.begin() + i);
			}
			
		}
	}
	void Registrar::enrollStudentInCourse(const std::string& nameOfStudent, const std::string& nameOfCourse)
	{
		findCourse(nameOfCourse)->enroll(findStudent(nameOfStudent));
		findStudent(nameOfStudent)->enroll(findCourse(nameOfCourse));
	}
	void Registrar::printReport() const
	{
		for (Course* c : courses)
		{
			cout << "Course: " << c->getName() << "; Students: ";
			for (Student* s : c->getStudents())
			{
				cout << s->getName() << " ";
			}
			cout << endl;
		}
	}
		/*void Registrar::purge()
		{
		for (size_t i = 0; i < students.size(); i++)
		{
		delete students[i];
		}
		for (size_t i = 0; i < courses.size(); i++)
		{
		delete courses[i];
		}
		students.clear();
		courses.clear();
		}*/

	
}