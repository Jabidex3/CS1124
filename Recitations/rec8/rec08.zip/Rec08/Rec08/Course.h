#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include <string>
#include <vector>

namespace BrooklynPoly
{
	class Student;

	class Course
	{
	private:
		std::string name;
		std::vector<Student*> students;

	public:
		Course(const std::string& name);
		std::string getName() const;
		std::vector<Student*> getStudents();
		void enroll(Student* stu);
		void drop(Student* stu);
	};
}

#endif