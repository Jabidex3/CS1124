#include "Course.h"
#include "Student.h"
#include<iostream>

using namespace std;
namespace BrooklynPoly
{
	Student::Student(const string& name) :name(name)
	{	}
	string Student::getName() const
	{
		return name;
	}
	vector<Course*> Student::getCourses()
	{
		return courses;
	}
	void Student::enroll(Course* course)
	{
		courses.push_back(course);
	}
	void Student::drop(Course* course)
	{
		for (size_t i = 0; i < courses.size(); i++)
		{
			if (courses[i]->getName() == course->getName())
			{
				courses[i] = courses[courses.size() - 1];
				courses.pop_back();
			}
				
		}
	}
}
