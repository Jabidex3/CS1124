#ifndef STUDENT_H
#define STUDENT_H

#include <vector>
#include <string>
#include <iostream>

namespace BrooklynPoly
{
	class Course;

	class Student
	{
	private:
		std::string name;
		std::vector<Course*> courses;

	public:
		Student(const std::string& name);
		std::string getName() const;
		std::vector<Course*> getCourses();
		void enroll(Course* course);
		void drop(Course* course);
	};
}

#endif