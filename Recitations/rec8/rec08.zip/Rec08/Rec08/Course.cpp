#include "Course.h"
#include "Student.h"
#include<iostream>

using namespace std;
namespace BrooklynPoly
{
	Course::Course(const string& name) : name(name) {}
	string Course::getName() const 
	{ 
		return name;
	}
	void Course::enroll(Student* stu)
	{
			stu->enroll(this);
			students.push_back(stu);

	}
	void Course::drop(Student* stu)
	{
		for (size_t i = 0; i < students.size(); i++)
		{
			if (students[i]->getName() == stu->getName())
			{
				students[i] = students[students.size() - 1];
				students.pop_back();
			}

		}
	}

	vector<Student*> Course::getStudents()
	{
		return students;
	}
}