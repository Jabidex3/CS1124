#ifndef REGISTRAR_H
#define REGISTRAR_H

#include "Student.h"
#include "Course.h"
#include<vector>
#include<string>
#include<iostream>

namespace BrooklynPoly
{
	class Student;
	class Course;
	class Registrar{
	public:
		void addCourse(const std::string& name);
		void cancelCourse(const std::string& name);
		void addStudent(const std::string& name);
		//void removeStudent(const std::string& name);//optional
		void enrollStudentInCourse(const std::string& nameOfStudent, const std::string& nameOfCourse);
		//void dropStudentFromCourse(std::string& nameOfStudent, std::string& nameOfCourse);//optional
		void purge();
		void printReport() const;
		friend std::ostream& operator<<(std::ostream& os, const Registrar &r);
	private:
		std::vector<Student*> students;
		std::vector<Course*> courses;
		Course* findCourse(const std::string& name);
		Student* findStudent(const std::string& name);
	};
}
#endif